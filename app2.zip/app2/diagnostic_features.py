# diagnostic_features.py
def analyze_feature_importance():
    """Анализ важности фич для улучшения модели"""
    from app2 import models as M
    bundle = M.load()

    # Анализ важности фич RandomForest
    if hasattr(bundle.get('rf'), 'feature_importances_'):
        importances = bundle['rf'].feature_importances_
        features = bundle.get('cols', [])

        # Сортируем по важности
        feature_importance = sorted(zip(features, importances),
                                    key=lambda x: x[1], reverse=True)

        print("ТОП-20 самых важных фич:")
        for feat, imp in feature_importance[:20]:
            print(f"  {feat}: {imp:.4f}")