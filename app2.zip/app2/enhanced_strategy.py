# Создать enhanced_strategy.py
def enhanced_signal_strategy(prices: pd.DataFrame, model_bundle, rp, equity: float):
    """Стратегия с улучшенными фильтрами"""
    from . import model_improvement as MI

    # Используем улучшенные фичи
    X = MI.create_improved_features(prices)
    p = M.predict_proba(model_bundle, X, prices['close'].astype(float))

    # СТРОГИЕ ФИЛЬТРЫ:
    # 1. Фильтр по объему
    volume_ratio = prices['volume'] / prices['volume'].rolling(20).mean()
    volume_ok = volume_ratio > 1.2

    # 2. Фильтр по волатильности
    volatility = prices['close'].pct_change().rolling(20).std()
    volatility_ok = volatility < 0.025

    # 3. Фильтр по моментуму
    momentum = prices['close'].pct_change(5)
    momentum_ok = abs(momentum) < 0.05

    # КОМБИНИРОВАННЫЕ УСЛОВИЯ
    long_cond = (p > 0.65) & volume_ok & volatility_ok & momentum_ok
    short_cond = (p < 0.35) & volume_ok & volatility_ok & momentum_ok

    # ...