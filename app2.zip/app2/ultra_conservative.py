# ultra_conservative.py
def ultra_conservative_strategy(prices: pd.DataFrame, model_bundle, rp, equity: float):
    """СВЕРХКОНСЕРВАТИВНАЯ стратегия - только лучшие сигналы"""

    X = F.build(prices)
    if X.empty or len(prices) < 100:
        return create_empty_signal(prices)

    p = M.predict_proba(model_bundle, X, prices['close'].astype(float))
    close = prices['close'].astype(float)
    volume = prices.get('volume', pd.Series(1, index=p.index))

    # СУПЕР-СТРОГИЕ ФИЛЬТРЫ:

    # 1. ТОЛЬКО СИЛЬНЫЕ СИГНАЛЫ
    strong_long = p > 0.75  # было 0.65
    strong_short = p < 0.25  # было 0.35

    # 2. ФИЛЬТР ТРЕНДА - только по тренду
    sma_20 = close.rolling(20).mean()
    sma_50 = close.rolling(50).mean()
    trend_up = sma_20 > sma_50
    trend_down = sma_20 < sma_50

    # 3. ФИЛЬТР ОБЪЕМА - объем в 2 раза выше среднего
    volume_ok = volume > volume.rolling(20).mean() * 2

    # 4. ФИЛЬТР ВОЛАТИЛЬНОСТИ - избегать экстремальных значений
    volatility = close.pct_change().rolling(20).std()
    volatility_ok = volatility.between(volatility.quantile(0.3), volatility.quantile(0.7))

    # КОМБИНИРОВАННЫЕ УСЛОВИЯ
    long_cond = strong_long & trend_up & volume_ok & volatility_ok
    short_cond = strong_short & trend_down & volume_ok & volatility_ok

    side = pd.Series(0, index=p.index)
    side[long_cond] = 1
    side[short_cond] = -1

    # МАЛЕНЬКИЙ ФИКСИРОВАННЫЙ РАЗМЕР
    size = side * (equity * 0.01)  # 1% капитала

    result = pd.DataFrame({'p': p, 'side': side, 'size': size}, index=prices.index)

    active_signals = result[result['side'] != 0]
    print(f"🎯 СВЕРХКОНСЕРВАТИВНАЯ СТРАТЕГИЯ:")
    print(f"   Всего сигналов: {len(active_signals)}")
    print(f"   Long: {(result['side'] == 1).sum()}, Short: {(result['side'] == -1).sum()}")
    print(f"   Средняя уверенность: {result[result['side'] != 0]['p'].mean():.3f}")

    return result