# threshold_calibration.py
from app2 import data as D, models as M, labels as L
from app2.model_improvement import create_improved_features
import pandas as pd
import numpy as np


def calibrate_gb_thresholds():
    """Калибровка оптимальных порогов для GB модели"""
    symbols = ['SBER', 'GAZP']  # Начнем с основных тикеров

    print("=== КАЛИБРОВКА ПОРОГОВ ДЛЯ GB МОДЕЛИ ===")

    # Загружаем данные
    prices_data = {}
    for symbol in symbols:
        prices = D.load_csv(symbol)
        if not prices.empty and len(prices) > 1000:
            prices_data[symbol] = prices
            print(f"📊 {symbol}: {len(prices)} баров")

    if not prices_data:
        print("❌ Недостаточно данных для калибровки")
        return

    # Обучаем GB модель
    from app2.model_improvement import train_gb_model
    gb_model = train_gb_model(prices_data, horizon=2)

    if gb_model is None:
        print("❌ Не удалось обучить модель для калибровки")
        return

    print("\n🎯 КАЛИБРОВКА ПОРОГОВ:")

    calibration_results = {}

    for symbol, prices in prices_data.items():
        print(f"\n🔍 {symbol}:")

        X = create_improved_features(prices)
        y_true = L.y_updown(prices['close'].astype(float), horizon=2)

        # Предсказания GB модели
        if hasattr(gb_model, 'feature_names_'):
            X_aligned = X.reindex(columns=gb_model.feature_names_, fill_value=0)
            p_pred = gb_model.predict_proba(X_aligned.values)[:, 1]
        else:
            p_pred = gb_model.predict_proba(X.values)[:, 1]

        # Тестируем разные пороги
        thresholds = np.arange(0.55, 0.85, 0.05)
        best_f1 = 0
        best_threshold = 0.65

        for threshold in thresholds:
            y_pred = (p_pred >= threshold).astype(int)

            # Выравниваем индексы
            common_idx = X.index.intersection(y_true.index)
            if len(common_idx) == 0:
                continue

            y_t = y_true.loc[common_idx]
            y_p = pd.Series(y_pred, index=X.index).loc[common_idx]

            # Считаем F1-score
            from sklearn.metrics import f1_score
            try:
                f1 = f1_score(y_t, y_p, zero_division=0)

                if f1 > best_f1:
                    best_f1 = f1
                    best_threshold = threshold
            except:
                continue

        calibration_results[symbol] = {
            'optimal_threshold': round(best_threshold, 3),
            'f1_score': round(best_f1, 4),
            'samples': len(X)
        }

        print(f"   Оптимальный порог: {best_threshold:.3f}")
        print(f"   F1-score: {best_f1:.4f}")

    # Сохраняем калибровку
    import json
    with open('gb_calibration.json', 'w') as f:
        json.dump(calibration_results, f, indent=2)

    print(f"\n💾 Калибровка сохранена в gb_calibration.json")

    return calibration_results


if __name__ == "__main__":
    calibrate_gb_thresholds()